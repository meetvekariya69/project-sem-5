<?php
session_start(); // Start the session

// Include the database configuration file
include("config.php");

// Check if user is logged in, if not redirect to the login page
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to book a package. Redirecting to login page.');</script>";
    header("Location: userlogin.php"); // Redirect to login page
    exit();
}

// Proceed with the booking functionality if user is logged in
if (isset($_GET['package_id'])) {
    $package_id = $_GET['package_id'];
    
    // Fetch package details
    $sql = "SELECT * FROM packages WHERE id = $package_id";
    $result = $conn->query($sql);
    $package = $result->fetch_assoc();
}

if (isset($_POST['book'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $package_id = $_POST['package_id'];

    // Make sure you are capturing these form inputs (or define them)
    $tour_name = $_POST['tour_name']; // Make sure this is an input in the form
    $tour_date = $_POST['tour_date']; // Make sure this is an input in the form
    
    // Insert booking details into the bookings table
    $sql1 = "INSERT INTO bookings (package_id, name, email, phone, status) VALUES ('$package_id', '$name', '$email', '$phone', 'pending')";
    
    if ($conn->query($sql1) === TRUE) {
        $booking_id = $conn->insert_id; // Get the last inserted ID for the booking

        // Insert into bookedpkg table with reference to the booking
        $sql2 = "INSERT INTO bookedpkg (package_id, booking_id, tour_name, tour_date, status) 
                 VALUES ('$package_id', '$booking_id', '$tour_name', '$tour_date', 'pending')";
        
        if ($conn->query($sql2) === TRUE) {
            echo "<script>alert('Booking successful! You will be contacted shortly.'); window.location.href='index.php';</script>";
        } else {
            echo "Error inserting into bookedpkg: " . $conn->error;
        }
    } else {
        echo "Error inserting into bookings: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Package</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Book Package: <?php echo $package['location']; ?></h1>
        <form method="post" action="">
            <input type="hidden" name="package_id" value="<?php echo $package_id; ?>">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
            </div>
            <!-- Add inputs for tour_name, tour_date, guests, and total_cost -->
            <div class="mb-3">
                <label for="tour_name" class="form-label">Tour Name</label>
                <input type="text" class="form-control" id="tour_name" name="tour_name" required>
            </div>
            <div class="mb-3">
                <label for="tour_date" class="form-label">Tour Date</label>
                <input type="date" class="form-control" id="tour_date" name="tour_date" required />
            </div>
            <button type="submit" name="book" class="btn btn-primary">Confirm Booking</button>
        </form>
    </div>
</body>
</html>
