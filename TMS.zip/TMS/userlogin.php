<?php
// Start the session
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'tms');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Check if the form is submitted
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve user data from the database
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify the password
        if (password_verify($password, $user['password'])) {

            // Store user data in the session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];

            // Redirect to the dashboard or home page
            header("Location: index.php");
            exit;
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with this email.";
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* General body styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f0f4f8;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Centered container for the login form */
.container {
    background-color: #fff;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 320px;
}

/* Heading style */
h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 24px;
    color: #333;
}

/* Input field styling */
.input-group {
    margin-bottom: 20px;
}

.input-group label {
    display: block;
    font-size: 14px;
    color: #333;
    margin-bottom: 8px;
}

.input-group input {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #f9f9f9;
}

.input-group input:focus {
    border-color: #5cb85c;
    background-color: #fff;
    outline: none;
    box-shadow: 0 0 5px rgba(92, 184, 92, 0.5);
}

/* Submit button styling */
button {
    width: 100%;
    padding: 12px;
    background-color: #5cb85c;
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #4cae4c;
}

/* Additional link or message styling */
p {
    text-align: center;
    font-size: 14px;
    color: #666;
    margin-top: 15px;
}

p a {
    color: #5cb85c;
    text-decoration: none;
}

p a:hover {
    text-decoration: underline;
}


.signup{
    display:flex;
    flex-direction:column;
    text-align:center;
}

a{
    color:green;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="post">
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>
        <div class="signup">
        <a href="sign-up form.php">Sign Up Here !</a>
        </div>
    </div>
</body>
</html>
