<?php
// Database connection
$servername = "localhost"; // Change if needed
$username = "root"; // Change if needed
$password = ""; // Change if needed
$dbname = "tms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch booked tours
$sql = "SELECT * FROM bookedpkg";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Panel</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 800px;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h1, h2 {
    color: #333;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

table, th, td {
    border: 1px solid #ccc;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

td {
    background-color: #ffffff;
}

a {
    color: #007bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.actions {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}

.actions a {
    padding: 10px 20px;
    background: #007bff;
    color: white;
    border-radius: 5px;
    transition: background 0.3s;
}

.actions a:hover {
    background: #0056b3;
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome, User!</h1>
        <h2>Your Booked Tours</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Tour Name</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($tour = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($tour['tour_name']); ?></td>
                        <td><?php echo htmlspecialchars($tour['tour_date']); ?></td>
                        <td><?php echo ucfirst($tour['status']); ?></td>
                       
                        <td>
                            <?php if ($tour['status'] == 'confirmed'): ?>
                                <a href="#">View Details</a>
                            <?php else: ?>
                                <div href="package.php">Book</div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No booked tours found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="actions">
            <a href="package.php">Book a New Tour</a>
            <a href="index.php">Back</a>
        </div>
    </div>

    <?php $conn->close(); ?>
</body>
</html>
